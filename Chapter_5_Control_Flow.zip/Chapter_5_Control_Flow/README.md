# 📦 Chapter 5 — Python Control Flow

This folder contains the GitHub-ready Markdown chapter and PNG flowchart diagrams.

Keep the `images` folder beside the Markdown file when uploading to GitHub so all diagrams render correctly.
